# Sakshi’s RBSE Class 10 English Test

This is a single-file static site for GitHub Pages with 50 hard multiple-choice questions, 60-minute timer, on-device scoring, section-wise report and one-attempt rule.

## Publish on GitHub Pages

1. Create a public GitHub repository (example: `sakshi-english-test`).
2. Add the `index.html` file to the repository root.
3. Under **Settings → Pages**, select **Deploy from a branch**; choose `main` and `/ (root)`; save.
4. Open `https://YOUR-USERNAME.github.io/sakshi-english-test/`.

## One-attempt rule

When a test is active, browser Back, refresh, leaving the page, or switching apps/tabs triggers the **Test Closed** screen. The attempt status is saved in localStorage. This is browser-based monitoring and cannot truly close a browser window or prevent all cheating. Opening from a different browser or clearing site data circumvents the lock. A browser tab may be suspended before events fire. Mobile system notifications may inadvertently trigger the rule. Communicate this strictness to the student.

Results are NOT sent to a server; the student must tap **Share / Copy Result** and send the report to the teacher.

**Important:** This is a practice test, not an official board paper. On a public static website, the scoring answers can be discovered by inspecting downloaded JavaScript. A secure exam and central teacher dashboard require a backend.
